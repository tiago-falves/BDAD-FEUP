
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: User
INSERT INTO User (uID, username, password, rating, photo, email) VALUES (1, 'JoaoRocha', 'password1', 5.0, 'joaophoto.png', 'up201708566@fe.up.pt');
INSERT INTO User (uID, username, password, rating, photo, email) VALUES (2, 'TiagoAlves', '123456789', 5.0, 'tiagophoto.png', 'up201603820@fe.up.pt');
INSERT INTO User (uID, username, password, rating, photo, email) VALUES (3, 'Francisco Batista', '987654321', 5.0, 'franciscophoto.png', 'up201604320@fe.up.pt');
INSERT INTO User (uID, username, password, rating, photo, email) VALUES (4, 'Jonathon May', 'jonathon', 2.5, NULL, 'jmay@gmail.com');
INSERT INTO User (uID, username, password, rating, photo, email) VALUES (5, 'Brogan Chester', 'namegenerator', 1.0, 'brogan.png', 'thisismyemail.com');
INSERT INTO User (uID, username, password, rating, photo, email) VALUES (6, 'Kier Allman', 'wordpass', NULL, NULL, 'kiers@gmail.com');

INSERT INTO Maker (name, countryOfOrigin) VALUES ('Ferrari', 'Italy');
INSERT INTO Maker (name, countryOfOrigin) VALUES ('Toyota', 'Japan');
INSERT INTO Maker (name, countryOfOrigin) VALUES ('VW', 'Germany');
INSERT INTO Maker (name, countryOfOrigin) VALUES ('BMW', 'Germany');
INSERT INTO Maker (name, countryOfOrigin) VALUES ('Tesla', 'USA');
INSERT INTO Maker (name, countryOfOrigin) VALUES ('Ford', 'USA');

INSERT INTO Model (name, maxCapacity, avgConsumption, maker) VALUES ('Corolla', 4, 6.7, 'Toyota');
INSERT INTO Model (name, maxCapacity, avgConsumption, maker) VALUES ('320d', 1, 7.0, 'BMW');
INSERT INTO Model (name, maxCapacity, avgConsumption, maker) VALUES ('Model 3', 6, 1.0, 'Tesla');
INSERT INTO Model (name, maxCapacity, avgConsumption, maker) VALUES ('Focus', 3, 6.5, 'Ford');
INSERT INTO Model (name, maxCapacity, avgConsumption, maker) VALUES ('Golf', 4, 5.9, 'VW');
INSERT INTO Model (name, maxCapacity, avgConsumption, maker) VALUES ('F8', 1, 15.0, 'Ferrari');

INSERT INTO Vehicle (plate, colour, driver, model) VALUES ('12AA34', 'blue', 1, 'Corolla');
INSERT INTO Vehicle (plate, colour, driver, model) VALUES ('TA01FE', 'Black', 2, 'F8');
INSERT INTO Vehicle (plate, colour, driver, model) VALUES ('FR55BA', 'yellow', 3, 'Focus');

INSERT INTO PaymentMethod (PID) VALUES (1);
INSERT INTO PaymentMethod (PID) VALUES (2);
INSERT INTO PaymentMethod (PID) VALUES (3);
INSERT INTO PaymentMethod (PID) VALUES (4);

INSERT INTO BankTransfer ("PID ", accountNumber) VALUES (1, 1234567890123456800000.0);
INSERT INTO BankTransfer ("PID ", accountNumber) VALUES (2, 9091251251532692017119232.);

INSERT INTO Cash (Pid) VALUES (3);
INSERT INTO Cash (Pid) VALUES (4);

INSERT INTO Address (addressId, streetName, doorNumber) VALUES (1, 'Rua da Feup', 1112);
INSERT INTO Address (addressId, streetName, doorNumber) VALUES (2, 'Rua Longe', 70);
INSERT INTO Address (addressId, streetName, doorNumber) VALUES (3, 'Rua de perto', 1);
INSERT INTO Address (addressId, streetName, doorNumber) VALUES (44, 'Rua Do estadio', 1000);
INSERT INTO Address (addressId, streetName, doorNumber) VALUES (4, 'Rua das Flores', 100);
INSERT INTO Address (addressId, streetName, doorNumber) VALUES (5, 'Rua Estreita', 99);

INSERT INTO listPassenger (lId, address) VALUES (1, 2);
INSERT INTO listPassenger (lId, address) VALUES (3, 44);

INSERT INTO Message (messageId, date, text, sender, receiver) VALUES (1, 20190423, 'Message1', 1, 2);
INSERT INTO Message (messageId, date, text, sender, receiver) VALUES (2, 20190424, 'I got your message', 2, 1);
INSERT INTO Message (messageId, date, text, sender, receiver) VALUES (4, 20190625, 'This is a message from the future', 5, 6);
INSERT INTO Message (messageId, date, text, sender, receiver) VALUES (5, 20190426, 'hello', 4, 2);

INSERT INTO Weekday (name) VALUES ( 'Monday');
INSERT INTO Weekday (name) VALUES ( 'Tuesday');
INSERT INTO Weekday (name) VALUES ( 'Wednesday');
INSERT INTO Weekday (name) VALUES ( 'Thursday');
INSERT INTO Weekday (name) VALUES ( 'Friday');
INSERT INTO Weekday (name) VALUES ( 'Saturday');
INSERT INTO Weekday (name) VALUES ( 'Sunday');

INSERT INTO Map (mapID, "order", path) VALUES (1, 1, 'path1.pathfile');
INSERT INTO Map (mapID, "order", path) VALUES (2, 3, 'path2.pathfile');
INSERT INTO Map (mapID, "order", path) VALUES (3, 1, 'path3.pathfile');

INSERT INTO Trip (TID, startTime, endTime, costPassenger, mapID, plate) VALUES (1, 1200, 1300, 2.0, 1, '12AA34');
INSERT INTO Trip (TID, startTime, endTime, costPassenger, mapID, plate) VALUES (2, 800, 1330, 5.24, 3, 'FR55BA');
INSERT INTO Trip (TID, startTime, endTime, costPassenger, mapID, plate) VALUES (3, 1915, 1924, 1.2, 2, 'TA01FE');

INSERT INTO Punctual (TID, date) VALUES (1, 20190420);
INSERT INTO Punctual (TID, date) VALUES (2, 20190421);

INSERT INTO Regular (TID, onHolidays, weekday) VALUES (3, 1, 'Monday');

INSERT INTO passenger (user, trip, paymentmethod) VALUES (2, 1, 1);
INSERT INTO passenger (user, trip, paymentmethod) VALUES (3, 1, 2);
INSERT INTO passenger (user, trip, paymentmethod) VALUES (5, 2, 4);

INSERT INTO stops ( address, map, listpassenger, order) VALUES ( 1, 2, 1, 1);
INSERT INTO stops ( address, map, listpassenger, order) VALUES ( 1, 2, 1, 2);



COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
